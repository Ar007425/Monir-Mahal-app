package com.monirmahal.app

import android.app.Activity
import android.os.Bundle
import android.content.Intent
import android.widget.*
import android.view.Gravity

class MainActivity : Activity() {
    private val prefs by lazy { getSharedPreferences("monir_mahal", MODE_PRIVATE) }
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        if (prefs.getString("pin", null) == null) showSetPin() else showUnlock()
    }
    private fun page(title: String): LinearLayout {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER_HORIZONTAL
            setPadding(24, 28, 24, 24); setBackgroundColor(0xFFFFF4F4.toInt())
        }
        root.addView(TextView(this).apply {
            text = title; textSize = 26f; setTextColor(0xFFB71C1C.toInt())
            gravity = Gravity.CENTER; setPadding(0, 12, 0, 28)
        })
        setContentView(root); return root
    }
    private fun showSetPin() {
        val root = page("MONIR MAHAL")
        root.addView(TextView(this).apply { text = "প্রথমবার ৮ সংখ্যার পাসওয়ার্ড তৈরি করুন"; textSize = 18f })
        val pin = EditText(this).apply { hint = "৮ সংখ্যার PIN"; inputType = 2 }
        root.addView(pin)
        root.addView(Button(this).apply { text = "সেভ করুন"; setOnClickListener {
            val p = pin.text.toString()
            if (p.length != 8 || !p.all { it.isDigit() }) Toast.makeText(this@MainActivity, "৮টি সংখ্যা দিন", Toast.LENGTH_SHORT).show()
            else { prefs.edit().putString("pin", p).apply(); showHome() }
        }})
    }
    private fun showUnlock() {
        val root = page("MONIR MAHAL")
        root.addView(TextView(this).apply { text = "৮ সংখ্যার পাসওয়ার্ড দিন"; textSize = 18f })
        val pin = EditText(this).apply { hint = "PIN"; inputType = 2 }
        root.addView(pin)
        root.addView(Button(this).apply { text = "খুলুন"; setOnClickListener {
            if (pin.text.toString() == prefs.getString("pin", "")) showHome()
            else Toast.makeText(this@MainActivity, "পাসওয়ার্ড সঠিক নয়", Toast.LENGTH_SHORT).show()
        }})
    }
    private fun showHome() {
        val root = page("MONIR MAHAL")
        root.addView(TextView(this).apply { text = "ভাড়াটিয়াদের নোটিশ"; textSize = 20f })
        val notices = listOf("লিফট সাময়িকভাবে বন্ধ থাকবে।", "পানি সরবরাহ সাময়িক বন্ধ থাকবে।", "বিদ্যুৎ সংক্রান্ত জরুরি নোটিশ।", "সবার জন্য জরুরি ঘোষণা।")
        notices.forEach { notice ->
            root.addView(Button(this).apply { text = notice; setOnClickListener { share(notice) } })
        }
        root.addView(Button(this).apply { text = "নিজের বার্তা লিখুন"; setOnClickListener {
            val input = EditText(this@MainActivity)
            android.app.AlertDialog.Builder(this@MainActivity).setTitle("নোটিশ লিখুন").setView(input)
                .setPositiveButton("শেয়ার") { _, _ -> share(input.text.toString()) }.setNegativeButton("বাতিল", null).show()
        }})
        root.addView(Button(this).apply { text = "ভয়েস কল সুবিধা"; setOnClickListener {
            Toast.makeText(this@MainActivity, "স্বয়ংক্রিয় কল চালু করতে আলাদা পেইড Voice Broadcast সার্ভিস লাগবে।", Toast.LENGTH_LONG).show()
        }})
        root.addView(TextView(this).apply {
            text = "নোট: এই প্রাথমিক সংস্করণে বার্তা শেয়ার করা যাবে। ১০ জনকে স্বয়ংক্রিয় WhatsApp পাঠানো বা স্বয়ংক্রিয় কল এখনো চালু নয়।"
            textSize = 14f; setPadding(4, 18, 4, 4)
        })
    }
    private fun share(message: String) {
        val intent = Intent(Intent.ACTION_SEND).apply { type = "text/plain"; putExtra(Intent.EXTRA_TEXT, message) }
        startActivity(Intent.createChooser(intent, "নোটিশ শেয়ার করুন"))
    }
}
